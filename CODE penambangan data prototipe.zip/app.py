from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import io
import base64
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

app = Flask(__name__)

# Fungsi untuk membuat prediksi penjualan
def forecast_sales(df):
    time_series = df['HARGA TOTAL PENJUALAN'].fillna(0)
    
    try:
        model = ARIMA(time_series, order=(1, 1, 1))
        model_fit = model.fit()
        forecast = model_fit.forecast(steps=5)
        
        forecast_table = pd.DataFrame({
            'Periode': range(1, 6),
            'Prediksi Penjualan': forecast
        })
        
        plt.figure(figsize=(10, 6))
        plt.plot(time_series, label='Data Penjualan')
        plt.plot(range(len(time_series), len(time_series) + len(forecast)), forecast, label='Forecast', color='orange')
        plt.title('Prediksi Penjualan')
        plt.xlabel('Waktu')
        plt.ylabel('Penjualan')
        plt.legend()
        plt.grid()

        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode('utf8')
        plt.close()

        return {'table': forecast_table.to_html(index=False), 'plot_url': f'data:image/png;base64,{plot_url}'}

    except Exception as e:
        return {"table": f"Error: {e}", "plot_url": ""}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        return redirect(url_for('index'))

    if file and file.filename.endswith('.csv'):
        try:
            # Membaca file CSV dengan header di baris ke-3 dan pemisah ";"
            df = pd.read_csv(file, skiprows=2, sep=';')
            df.columns = df.columns.str.strip().str.upper()

            required_columns = ['PRODUK', 'JUMLAH PENJUALAN', 'HARGA TOTAL PENJUALAN', 'HARGA PRODUK']
            for col in required_columns:
                if col not in df.columns:
                    return f"Kolom '{col}' tidak ditemukan dalam data."

            df['HARGA TOTAL PENJUALAN'] = pd.to_numeric(df['HARGA TOTAL PENJUALAN'], errors='coerce').fillna(0)

            forecast_result = forecast_sales(df)
            
            return render_template(
                'results.html',
                data=df.to_html(index=False, classes="table table-bordered"),
                forecast_table=forecast_result['table'],
                plot_url=forecast_result['plot_url']
            )
        except Exception as e:
            return f"Terjadi kesalahan: {e}"

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
