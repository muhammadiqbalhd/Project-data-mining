import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from io import BytesIO
import base64

def forecast_sales(df):
    # Pastikan kolom penjualan hanya angka
    df = df[['HARGA TOTAL PENJUALAN']].copy()

    # Tambahkan tanggal dummy jika tidak ada kolom tanggal
    df['Month'] = pd.date_range(start='2023-01-01', periods=len(df), freq='M')
    df.set_index('Month', inplace=True)

    # Pastikan tidak ada nilai kosong
    df = df.dropna()

    # Model ARIMA
    try:
        model = ARIMA(df['HARGA TOTAL PENJUALAN'], order=(5, 1, 0))
        model_fit = model.fit()

        # Prediksi 12 bulan ke depan
        forecast = model_fit.forecast(steps=12)
        forecast_index = pd.date_range(start=df.index[-1], periods=13, freq='M')[1:]
        forecast_df = pd.DataFrame(forecast, index=forecast_index, columns=['Forecast'])

        # Plot hasil
        plt.figure(figsize=(10, 6))
        plt.plot(df.index, df['HARGA TOTAL PENJUALAN'], label='Penjualan Historis')
        plt.plot(forecast_df.index, forecast_df['Forecast'], label='Prediksi', color='red')
        plt.title('Prediksi Tren Penjualan')
        plt.xlabel('Bulan')
        plt.ylabel('Penjualan (Rp)')
        plt.legend()

        # Simpan grafik ke base64
        img = BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode('utf8')

        return {
            'table': forecast_df.to_html(classes='table', border=0),
            'plot_url': f"data:image/png;base64,{plot_url}"
        }
    except Exception as e:
        return {"table": f"Error: {e}", "plot_url": ""}
